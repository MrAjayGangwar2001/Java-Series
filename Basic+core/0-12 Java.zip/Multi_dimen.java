public class Multi_dimen {
    public static void main(String[] args) {
        /*
         * int arr[][] = new int [3][4];
         * 
         * for (int i = 0; i <3; i++) {
         * for (int j = 0; j <4; j++) {
         * arr[i][j] = (int)(Math.random()*10);
         * }
         * }
         * for (int i = 0; i <3; i++) {
         * for (int j = 0; j <4; j++) {
         * System.out.print(arr[i][j] +" ");
         * }
         * System.out.println();
         * }
         * 
         * // Now we will try enhanced for loop that work like upper for loop
         * for(int a[] : arr)
         * {
         * for(int b : a){
         * System.out.print(b +" ");
         * }
         * System.out.println();
         * }
         */

        int jagarr[][] = new int[3][]; // jagged Array(custom nested Array Size)
        jagarr[0] = new int[4];
        jagarr[1] = new int[3];
        jagarr[2] = new int[5];

        for (int i = 0; i < jagarr.length; i++) {
            for (int j = 0; j < jagarr[i].length; j++) {
                jagarr[i][j] = (int) (Math.random() * 10);
            }
        }

        for (int a[] : jagarr) {
            for (int b : a) {
                System.out.print(b + " ");
            }
            System.out.println();
        }
    }
}