class Overloading {
    public int parameter(int a, int b) {
        return a + b;
    }

    public int parameter(int a, int b, int c) {
        return a + b + c;
    }

    public double parameter(double a, int b) {
        return a + b;
    }
    public double addition(double a, int b) {
        return a + b;
    }
}

public class Method_overloading {
    public static void main(String[] args) {
        Overloading over = new Overloading();
        int add = over.parameter(5, 7);
        int add1 = over.parameter(5, 7, 4); // With different parameters
        double add2 = over.parameter(5.56, 7); // With different parameters
        double add3 = over.addition(6.6 , 5);
        System.out.println("overloading with parameter:- " + add);
        System.out.println("overloading Same name with different parameter:- " + add1);
        System.out.println("overloading Same name with different parameter Type:- " + add2);
        System.out.println("overloading different name with same parameter:- " + add3);
    }
}