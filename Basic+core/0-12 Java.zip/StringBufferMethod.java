public class StringBufferMethod{
    public static void main(String[] args) {
        
        StringBuffer sb = new StringBuffer("Ajay");
        sb.append(" Gangwar");
        int ab = sb.capacity();
        sb.deleteCharAt(0) ;
        sb.insert(0 , "Mr.");
        sb.insert(3 , "A");
        System.out.println(sb);
        System.out.println(ab);
         
    }

}