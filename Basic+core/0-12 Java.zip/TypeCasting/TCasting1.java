package TypeCasting;

public class TCasting1 {
    public static void main(String[] args) {
        
        double n = 56.52;
        int i = (int)n;
        System.out.println(i);
    }
}
