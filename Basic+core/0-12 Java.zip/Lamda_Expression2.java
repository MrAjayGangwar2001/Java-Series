// Lamda Expression
// Here we are using with Parameter

@FunctionalInterface
interface X{
    void display(int a);
}


public class Lamda_Expression2 {
    public static void main(String[] args) {
        X obj = a -> System.out.println("This is example of Lamda Expression with Parameters" + AA);
        obj.display(7);
    }
}
