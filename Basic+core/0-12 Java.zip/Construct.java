 class A{

    public A() {
        super();
        System.out.println("A int");
    }

    public A(int a) {
        super();
        System.out.println("In A int");
    }

}
class B extends A {

    public B() {
        super();
        System.out.println("A int");
    }

    public B(int a) {
        //super();   OR
        this();
        System.out.println("In A int");
    }

}
 

public class Construct{
    public static void main(String[] args) {
        B obj = new B(5);

    }
}