// We will learn Exceptions


// 1. Compile time Error
// 2. Run time Error   ------👉👉👉  Exception Handling
// 3. Logical Error