public class VeryAdvCalc extends advanceCalc
{
    public double pow(int n1 , int n2)
    {
        return Math.pow(n1, n2);
    }
}
