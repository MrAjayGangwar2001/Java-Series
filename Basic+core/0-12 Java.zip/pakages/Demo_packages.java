// package pakages;

// public class Demo_packages {
//     public static void main(String[] args) {
        
//     }
// }



// Package is a structured of Files and Folder
//  Package manage files in Folder
//  Package is Useful to Import file from Another Folder by Using import (package name).(file name) 
//  ex. import tool.Calc;
// 
// I Used Package in Method Overridding1 and 2.
//   also imported file from others
